#! /usr/bin/bash

echo "Configuring the VM..."
touch configured.txt
echo "Configured the VM."
