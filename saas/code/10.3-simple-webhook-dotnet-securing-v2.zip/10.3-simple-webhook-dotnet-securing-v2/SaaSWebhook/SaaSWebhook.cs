using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;

namespace SaaSWebhook;

/// <summary>
/// HTTP POST-triggered webhook that receives a JSON payload and stores it in Cosmos DB.
/// </summary>
public static class SaaSWebhook
{
    private static ILogger _logger;
    private static HttpRequest _request;

    /// <summary>
    /// Entry point for the Azure Function. Receives a JSON payload and stores it in Cosmos DB.
    /// </summary>
    /// <param name="req">The HTTP request</param>
    /// <param name="log">The ILogger for logging information</param>
    /// <returns>An ActionResult Task</returns>
    [FunctionName("SaaSWebhook")]
    public static async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
        ILogger log)
    {
        _request = req;
        _logger = log;
            
        _logger.LogInformation("Webhook invoked.");

        // check the JWT and its claims to ensure the request is valid
        if (!JwtIsValid())
        {
            _logger.LogCritical("JWT security checks failed!");

            return new BadRequestResult();
        }

        #region

        // read the input POST body
        var requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        dynamic body = JsonConvert.DeserializeObject(requestBody);

        // create an item to store in Cosmos DB
        var item = new
        {
            id = Guid.NewGuid().ToString(), 
            payload = body
        };
            
        await StorePayload(item);
        
        #endregion

        return new OkResult();
    }

    /// <summary>
    /// Checks that the JWT is valid.
    /// </summary>
    /// <returns>A bool indicating if the Claims in the JWT are valid.</returns>
    private static bool JwtIsValid()
    {
        // Retrieve and ensure the Authorization header
        string authHeader = _request.Headers["Authorization"];

        if (string.IsNullOrEmpty(authHeader))
        {
            _logger.LogCritical("Authorization header is missing.");
            
            return false;
        }
            
        // Get the JWT token from the Authorization header
        var jwt = authHeader.Split(' ')[1]; // get the JWT portion of the Authorization header
        _logger.LogInformation($"JWT token: {jwt}");
            
        var handler = new JwtSecurityTokenHandler();

        // Ensure the JWT is readable
        if (!handler.CanReadToken(jwt))
        {
            _logger.LogCritical("Can't read JWT");

            return false;
        }

        // Read the JWT
        if (handler.ReadToken(jwt) is not JwtSecurityToken jwtToken)
        {
            _logger.LogCritical("JWT is missing");

            return false;
        }

        // Check the claims in the JWT and return the result
        return JwtClaimsAreValid(jwtToken);
    }

    /// <summary>
    /// Ensure the claims in the JWT are valid.
    /// </summary>
    /// <param name="jwtToken"></param>
    /// <returns>A bool indicating whether the required claims are valid</returns>
    private static bool JwtClaimsAreValid(JwtSecurityToken jwtToken)
    {
        //==============================================================================================
        // Use raw reading of claims to avoid dependency on a specific library or .NET ClaimsPrincipal
        //==============================================================================================

        var isValid = true;

        // aud
        // Check the Entra ID application ID in the offer's technical configuration in Partner Center
        var clientId = jwtToken.Claims.FirstOrDefault(c => c.Type == "aud")!.Value;
        var expectedClientId = Environment.GetEnvironmentVariable("ClientId");
        if (clientId != expectedClientId)
        {
            _logger.LogWarning("Client ID does not match.");
            _logger.LogWarning($"Expected Client ID: {expectedClientId}");
            _logger.LogWarning($"Found Client ID: {clientId}");

            isValid = false;
        }

        // tid
        // Check the Entra tenant ID in the offer's technical configuration in Partner Center
        var tenantId = jwtToken.Claims.FirstOrDefault(c => c.Type == "tid")!.Value;
        var expectedTenantId = Environment.GetEnvironmentVariable("TenantId");
        if (tenantId != expectedTenantId)
        {
            _logger.LogWarning("Tenant ID does not match.");
            _logger.LogWarning($"Expected Tenant ID: {expectedTenantId}");
            _logger.LogWarning($"Found Tenant ID: {tenantId}");
            
            isValid = false;
        }

        // iss
        // Check the Entra tenant ID in the offer's technical configuration in Partner Center
        var expectedIssuer = $"https://sts.windows.net/{expectedTenantId}/";
        var issuer = jwtToken.Claims.FirstOrDefault(c => c.Type == "iss")!.Value;
        if (issuer != expectedIssuer)
        {
            _logger.LogWarning("Issuer does not match.");
            _logger.LogWarning($"Expected Issuer: {expectedIssuer}");
            _logger.LogWarning($"Found Issuer: {tenantId}");

            isValid = false;
        }

        
        // appid or azp
        // Check the resource ID used when you create the authorization token
        var resourceId = jwtToken.Claims.FirstOrDefault(c => c.Type is "appid" or "azp")?.Value;
        var expectedResourceId = Environment.GetEnvironmentVariable("ResourceId");
        if (resourceId != expectedResourceId)
        {
            _logger.LogWarning("Resource ID does not match.");
            _logger.LogWarning($"Expected Resource ID: {expectedResourceId}");
            _logger.LogWarning($"Found Resource ID: {resourceId}");
            
            isValid = false;
        }

        return isValid;
    }

    /// <summary>
    /// Save the payload to Cosmos DB
    /// </summary>
    /// <param name="item">The item to save to Cosmos DB</param>
    /// <returns></returns>
    private static async Task StorePayload(object item)
    {
        _logger.LogInformation("Saving JSON");

        var databaseName = Environment.GetEnvironmentVariable("CosmosDatabaseName");
        var containerName = Environment.GetEnvironmentVariable("CosmosContainerName"); 
        
        using var cosmosClient = GetCosmosClient();

        var database = await cosmosClient.CreateDatabaseIfNotExistsAsync(databaseName);
        var container = await database.Database.CreateContainerIfNotExistsAsync(containerName, "/id");

        await container.Container.CreateItemAsync(item);

        _logger.LogInformation("Saved JSON");

    }

    /// <summary>
    /// Get the client for Cosmos DB
    /// </summary>
    /// <returns>The initialized CosmosClient</returns>
    private static CosmosClient GetCosmosClient()
    {
        var primaryKey = Environment.GetEnvironmentVariable("CosmosPrimaryKey");
        var endpointUri = Environment.GetEnvironmentVariable("CosmosEndpoint");
        var applicationName = Environment.GetEnvironmentVariable("CosmosApplicationName");

        return new CosmosClient(endpointUri, primaryKey, new CosmosClientOptions()
        {
            ApplicationName = applicationName
        });
    }

}